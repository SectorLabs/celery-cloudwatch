from .monitor import main as celery_cloudwatch

__all__ = [
    'celery_cloudwatch'
]
